"""
01_generate_raw_data.py
------------------------
Generates a realistic MESSY retail sales export — the kind of raw file a
small e-commerce / retail client actually hands over (inconsistent dates,
currency symbols, duplicate rows, typos in categories, missing values,
negative/return quantities, and a couple of outlier data-entry errors).

This simulates the "before" state. Run this first.
"""

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

N = 2500

# ---- base reference data -------------------------------------------------
categories_clean = ["Electronics", "Apparel", "Home & Kitchen", "Beauty", "Sports", "Toys"]
# messy variants that a real spreadsheet would contain
category_variants = {
    "Electronics": ["Electronics", "electronics", "ELECTRONICS", "Electronic", "Electronics "],
    "Apparel": ["Apparel", "apparel", "APPAREL", "Appreal", " Apparel"],
    "Home & Kitchen": ["Home & Kitchen", "home & kitchen", "Home and Kitchen", "Home&Kitchen"],
    "Beauty": ["Beauty", "beauty", "BEAUTY", "Beuty"],
    "Sports": ["Sports", "sports", "SPORTS", "Sport"],
    "Toys": ["Toys", "toys", "TOYS", "Toy"],
}

products = {
    "Electronics": ["Wireless Earbuds", "Bluetooth Speaker", "Power Bank", "Smart Watch", "USB-C Cable"],
    "Apparel": ["Cotton T-Shirt", "Denim Jacket", "Running Shoes", "Hoodie", "Formal Shirt"],
    "Home & Kitchen": ["Non-Stick Pan", "Blender", "LED Lamp", "Storage Rack", "Vacuum Flask"],
    "Beauty": ["Face Serum", "Sunscreen SPF50", "Lip Balm Set", "Hair Dryer", "Makeup Kit"],
    "Sports": ["Yoga Mat", "Dumbbell Set", "Cricket Bat", "Football", "Resistance Bands"],
    "Toys": ["Building Blocks", "RC Car", "Puzzle Set", "Action Figure", "Board Game"],
}

regions_clean = ["Punjab", "Sindh", "KPK", "Balochistan", "Islamabad"]
region_variants = {
    "Punjab": ["Punjab", "punjab", "PB", "PUNJAB"],
    "Sindh": ["Sindh", "sindh", "SD"],
    "KPK": ["KPK", "kpk", "Khyber Pakhtunkhwa"],
    "Balochistan": ["Balochistan", "balochistan", "BL"],
    "Islamabad": ["Islamabad", "islamabad", "ISB"],
}

payment_methods = ["Credit Card", "Cash on Delivery", "Bank Transfer", "EasyPaisa", "JazzCash"]
first_names = ["Ali", "Sara", "Hamza", "Ayesha", "Bilal", "Fatima", "Usman", "Zara", "Omar", "Hina",
               "Ahmed", "Mahnoor", "Talha", "Sana", "Zain", "Iqra", "Faizan", "Noor", "Danish", "Amna"]
last_names = ["Khan", "Ahmed", "Malik", "Raza", "Sheikh", "Iqbal", "Butt", "Chaudhry", "Baig", "Hassan"]

date_formats = ["%Y-%m-%d", "%d/%m/%Y", "%m-%d-%Y", "%d-%b-%Y", "%Y/%m/%d %H:%M"]

rows = []
order_id_start = 100000

for i in range(N):
    cat = rng.choice(categories_clean)
    product = rng.choice(products[cat])
    region = rng.choice(regions_clean)

    # messy category / region text
    cat_text = rng.choice(category_variants[cat])
    region_text = rng.choice(region_variants[region])

    # date: random date in last 14 months, formatted inconsistently, occasionally missing
    days_back = rng.integers(0, 430)
    dt = pd.Timestamp("2026-09-14") - pd.Timedelta(days=int(days_back))
    fmt = rng.choice(date_formats)
    date_text = dt.strftime(fmt)
    if rng.random() < 0.02:
        date_text = ""  # missing date

    # quantity: mostly normal, some returns (negative), some missing, rare wild outlier
    qty_roll = rng.random()
    if qty_roll < 0.06:
        quantity = -int(rng.integers(1, 4))  # return
    elif qty_roll < 0.08:
        quantity = np.nan  # missing
    elif qty_roll < 0.085:
        quantity = 500  # data-entry error outlier
    else:
        quantity = int(rng.integers(1, 6))

    # unit price: messy currency formatting, some missing
    base_price = float(rng.integers(300, 15000))
    price_roll = rng.random()
    if price_roll < 0.03:
        price_text = ""
    elif price_roll < 0.35:
        price_text = f"Rs. {base_price:,.0f}"
    elif price_roll < 0.55:
        price_text = f"PKR {base_price:,.0f}"
    elif price_roll < 0.60:
        price_text = f"{base_price:,.2f} "
    else:
        price_text = f"{base_price:.0f}"

    # customer name, sometimes missing
    name = f"{rng.choice(first_names)} {rng.choice(last_names)}"
    if rng.random() < 0.015:
        name = ""

    status = rng.choice(["Completed", "Completed", "Completed", "Returned", "Cancelled"])

    rows.append({
        "OrderID": order_id_start + i,
        "OrderDate": date_text,
        "CustomerName": name,
        "Region": region_text,
        "Category": cat_text,
        "Product": product,
        "Quantity": quantity,
        "UnitPrice": price_text,
        "PaymentMethod": rng.choice(payment_methods),
        "Status": status,
    })

df = pd.DataFrame(rows)

# inject ~1.5% exact duplicate rows (very common in real client exports —
# double-clicked export button, merged sheets, etc.)
dup_frac = 0.015
n_dupes = int(len(df) * dup_frac)
dupes = df.sample(n=n_dupes, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)

# shuffle rows so duplicates aren't neatly grouped, like a real messy file
df = df.sample(frac=1, random_state=7).reset_index(drop=True)

df.to_csv("/home/claude/retail-data-cleaning-pipeline/data/raw/raw_sales_export.csv", index=False)
print(f"Raw messy file written: {len(df)} rows")
print(df.head(8).to_string())
