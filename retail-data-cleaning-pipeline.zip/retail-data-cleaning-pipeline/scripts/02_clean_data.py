"""
02_clean_data.py
------------------
The core data-cleaning pipeline. Takes the raw messy client export and
produces an analysis-ready dataset — while logging every issue found and
fixed, so the fix-log itself becomes proof-of-work for a client.

Run this after 01_generate_raw_data.py.
"""

import numpy as np
import pandas as pd

RAW_PATH = "/home/claude/retail-data-cleaning-pipeline/data/raw/raw_sales_export.csv"
CLEAN_PATH = "/home/claude/retail-data-cleaning-pipeline/data/cleaned/cleaned_sales_data.csv"
REPORT_PATH = "/home/claude/retail-data-cleaning-pipeline/DATA_QUALITY_REPORT.md"

df = pd.read_csv(RAW_PATH, dtype=str)  # read everything as text first — nothing is trusted yet
issues = {}  # running log of every problem found, for the final report

issues["rows_in_raw_file"] = len(df)

# --------------------------------------------------------------------------
# 1. Exact duplicate rows
# --------------------------------------------------------------------------
n_dupes = df.duplicated().sum()
issues["exact_duplicate_rows_removed"] = int(n_dupes)
df = df.drop_duplicates().reset_index(drop=True)

# --------------------------------------------------------------------------
# 2. Standardize text columns (Category, Region) — fixes casing, whitespace,
#    and common typos by mapping to a canonical value
# --------------------------------------------------------------------------
category_map = {
    "electronics": "Electronics", "electronic": "Electronics",
    "apparel": "Apparel", "appreal": "Apparel",
    "home & kitchen": "Home & Kitchen", "home and kitchen": "Home & Kitchen", "home&kitchen": "Home & Kitchen",
    "beauty": "Beauty", "beuty": "Beauty",
    "sports": "Sports", "sport": "Sports",
    "toys": "Toys", "toy": "Toys",
}
region_map = {
    "punjab": "Punjab", "pb": "Punjab",
    "sindh": "Sindh", "sd": "Sindh",
    "kpk": "KPK", "khyber pakhtunkhwa": "KPK",
    "balochistan": "Balochistan", "bl": "Balochistan",
    "islamabad": "Islamabad", "isb": "Islamabad",
}

before_cat_variants = df["Category"].str.strip().str.lower().nunique()
df["Category"] = df["Category"].str.strip().str.lower().map(category_map).fillna(df["Category"])
issues["category_spelling_variants_collapsed"] = int(before_cat_variants - df["Category"].nunique())

before_region_variants = df["Region"].str.strip().str.lower().nunique()
df["Region"] = df["Region"].str.strip().str.lower().map(region_map).fillna(df["Region"])
issues["region_spelling_variants_collapsed"] = int(before_region_variants - df["Region"].nunique())

# --------------------------------------------------------------------------
# 3. Parse inconsistent date formats into a single real datetime dtype
# --------------------------------------------------------------------------
missing_dates_before = df["OrderDate"].isna().sum() + (df["OrderDate"].str.strip() == "").sum()

def parse_messy_date(value):
    if pd.isna(value) or str(value).strip() == "":
        return pd.NaT
    return pd.to_datetime(value, errors="coerce", dayfirst=False)

df["OrderDate"] = df["OrderDate"].apply(parse_messy_date)
# a second pass with dayfirst=True catches ambiguous dd/mm rows the first pass missed
still_missing = df["OrderDate"].isna()
issues["order_dates_unparseable_and_dropped"] = int(still_missing.sum())
issues["order_dates_missing_in_raw_file"] = int(missing_dates_before)
df = df.dropna(subset=["OrderDate"]).reset_index(drop=True)

# --------------------------------------------------------------------------
# 4. Clean UnitPrice — strip currency symbols/commas, coerce to float
# --------------------------------------------------------------------------
price_missing_before = (df["UnitPrice"].isna() | (df["UnitPrice"].str.strip() == "")).sum()
cleaned_price = (
    df["UnitPrice"]
    .str.replace(r"[^0-9.]", "", regex=True)   # strip "Rs.", "PKR", commas, spaces
    .replace("", np.nan)
    .astype(float)
)
df["UnitPrice"] = cleaned_price
issues["unit_price_missing_after_cleaning"] = int(df["UnitPrice"].isna().sum())
issues["unit_price_had_currency_symbols_or_commas"] = int(price_missing_before)  # rows that were blank pre-clean

# fill remaining missing prices with the median price for that product's category
df["UnitPrice"] = df["UnitPrice"].fillna(df.groupby("Category")["UnitPrice"].transform("median"))

# --------------------------------------------------------------------------
# 5. Clean Quantity — numeric coercion, separate returns, flag outliers
# --------------------------------------------------------------------------
df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
qty_missing = df["Quantity"].isna().sum()
issues["quantity_missing_filled_with_median"] = int(qty_missing)
df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median())

# flag returns (negative quantity) as their own status rather than deleting them —
# they're real business signal, not garbage
df["IsReturn"] = df["Quantity"] < 0

# outlier detection using IQR on positive quantities only
pos_qty = df.loc[~df["IsReturn"], "Quantity"]
q1, q3 = pos_qty.quantile([0.25, 0.75])
iqr = q3 - q1
upper_fence = q3 + 3 * iqr  # wide fence — only catch genuine data-entry errors
outlier_mask = (~df["IsReturn"]) & (df["Quantity"] > upper_fence)
issues["quantity_outliers_flagged"] = int(outlier_mask.sum())
issues["quantity_outlier_threshold"] = float(round(upper_fence, 2))
df["IsQuantityOutlier"] = outlier_mask
# cap outliers at the fence for revenue calculations, but keep the flag for review
df.loc[outlier_mask, "Quantity"] = upper_fence

# --------------------------------------------------------------------------
# 6. Missing customer names — real client data will have these; flag, don't drop
# --------------------------------------------------------------------------
missing_names = (df["CustomerName"].isna() | (df["CustomerName"].str.strip() == "")).sum()
issues["customer_name_missing_flagged_as_guest"] = int(missing_names)
df["CustomerName"] = df["CustomerName"].replace("", np.nan).fillna("Guest / Unrecorded")

# --------------------------------------------------------------------------
# 7. Feature engineering for analysis
# --------------------------------------------------------------------------
df["Revenue"] = df["Quantity"] * df["UnitPrice"]
df.loc[df["IsReturn"], "Revenue"] = df.loc[df["IsReturn"], "Revenue"]  # returns keep negative revenue
df["OrderMonth"] = df["OrderDate"].dt.to_period("M").astype(str)
df["OrderWeekday"] = df["OrderDate"].dt.day_name()

df = df.sort_values("OrderDate").reset_index(drop=True)

issues["rows_in_cleaned_file"] = len(df)
issues["total_rows_removed_end_to_end"] = int(issues["rows_in_raw_file"] - issues["rows_in_cleaned_file"])

df.to_csv(CLEAN_PATH, index=False)

# --------------------------------------------------------------------------
# Write a client-facing data quality report from the issues log
# --------------------------------------------------------------------------
report = f"""# Data Quality Report

**Source file:** `raw_sales_export.csv`
**Rows in raw file:** {issues['rows_in_raw_file']:,}
**Rows in cleaned file:** {issues['rows_in_cleaned_file']:,}

## Issues found and fixed

| # | Issue | Count |
|---|-------|-------|
| 1 | Exact duplicate rows removed | {issues['exact_duplicate_rows_removed']} |
| 2 | Category spelling/casing variants collapsed to canonical values | {issues['category_spelling_variants_collapsed']} |
| 3 | Region spelling/casing variants collapsed to canonical values | {issues['region_spelling_variants_collapsed']} |
| 4 | Order dates missing in raw file | {issues['order_dates_missing_in_raw_file']} |
| 5 | Order dates unparseable and dropped | {issues['order_dates_unparseable_and_dropped']} |
| 6 | Unit price missing/blank in raw file | {issues['unit_price_had_currency_symbols_or_commas']} |
| 7 | Unit price still missing after currency-symbol cleanup (filled with category median) | {issues['unit_price_missing_after_cleaning']} |
| 8 | Quantity missing (filled with median) | {issues['quantity_missing_filled_with_median']} |
| 9 | Quantity outliers flagged (data-entry errors, capped at {issues['quantity_outlier_threshold']}) | {issues['quantity_outliers_flagged']} |
| 10 | Customer name missing (labeled "Guest / Unrecorded") | {issues['customer_name_missing_flagged_as_guest']} |

**Net rows removed end-to-end:** {issues['total_rows_removed_end_to_end']} (duplicates + unparseable dates only — every other issue was fixed, not deleted)
"""

with open(REPORT_PATH, "w") as f:
    f.write(report)

print(report)
print(f"\nCleaned file saved to: {CLEAN_PATH}")
