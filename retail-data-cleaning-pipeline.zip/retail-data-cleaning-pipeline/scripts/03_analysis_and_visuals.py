"""
03_analysis_and_visuals.py
----------------------------
Turns the cleaned dataset into business-facing insights and matplotlib
charts — the kind of visuals a client actually wants to see, not just
raw tables.

Run this after 02_clean_data.py.
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

CLEAN_PATH = "/home/claude/retail-data-cleaning-pipeline/data/cleaned/cleaned_sales_data.csv"
VIS_DIR = "/home/claude/retail-data-cleaning-pipeline/visuals"

plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#333333",
    "axes.grid": True,
    "grid.color": "#e0e0e0",
    "grid.linewidth": 0.6,
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.titleweight": "bold",
})

df = pd.read_csv(CLEAN_PATH, parse_dates=["OrderDate"])
completed = df[df["Status"] == "Completed"].copy()

# --------------------------------------------------------------------------
# 1. Monthly revenue trend
# --------------------------------------------------------------------------
monthly = completed.groupby("OrderMonth")["Revenue"].sum().sort_index()

fig, ax = plt.subplots(figsize=(9, 4.5))
ax.plot(monthly.index, monthly.values, marker="o", color="#2563eb", linewidth=2)
ax.set_title("Monthly Revenue Trend (Completed Orders)")
ax.set_ylabel("Revenue (PKR)")
ax.set_xlabel("Month")
plt.xticks(rotation=45, ha="right")
ax.yaxis.set_major_formatter(lambda x, _: f"{x/1000:,.0f}K")
fig.tight_layout()
fig.savefig(f"{VIS_DIR}/01_monthly_revenue_trend.png", dpi=150)
plt.close(fig)

# --------------------------------------------------------------------------
# 2. Revenue by category
# --------------------------------------------------------------------------
by_cat = completed.groupby("Category")["Revenue"].sum().sort_values(ascending=True)

fig, ax = plt.subplots(figsize=(8, 4.5))
bars = ax.barh(by_cat.index, by_cat.values, color="#16a34a")
ax.set_title("Total Revenue by Category")
ax.set_xlabel("Revenue (PKR)")
ax.xaxis.set_major_formatter(lambda x, _: f"{x/1000:,.0f}K")
for bar, val in zip(bars, by_cat.values):
    ax.text(val, bar.get_y() + bar.get_height() / 2, f" {val/1000:,.0f}K",
            va="center", fontsize=9, color="#333333")
fig.tight_layout()
fig.savefig(f"{VIS_DIR}/02_revenue_by_category.png", dpi=150)
plt.close(fig)

# --------------------------------------------------------------------------
# 3. Revenue by region
# --------------------------------------------------------------------------
by_region = completed.groupby("Region")["Revenue"].sum().sort_values(ascending=False)

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.bar(by_region.index, by_region.values, color="#ea580c")
ax.set_title("Total Revenue by Region")
ax.set_ylabel("Revenue (PKR)")
ax.yaxis.set_major_formatter(lambda x, _: f"{x/1000:,.0f}K")
fig.tight_layout()
fig.savefig(f"{VIS_DIR}/03_revenue_by_region.png", dpi=150)
plt.close(fig)

# --------------------------------------------------------------------------
# 4. Top 10 products by revenue
# --------------------------------------------------------------------------
top_products = completed.groupby("Product")["Revenue"].sum().sort_values(ascending=True).tail(10)

fig, ax = plt.subplots(figsize=(8, 5))
ax.barh(top_products.index, top_products.values, color="#7c3aed")
ax.set_title("Top 10 Products by Revenue")
ax.set_xlabel("Revenue (PKR)")
ax.xaxis.set_major_formatter(lambda x, _: f"{x/1000:,.0f}K")
fig.tight_layout()
fig.savefig(f"{VIS_DIR}/04_top_products.png", dpi=150)
plt.close(fig)

# --------------------------------------------------------------------------
# 5. Order status breakdown + return rate
# --------------------------------------------------------------------------
status_counts = df["Status"].value_counts()

fig, ax = plt.subplots(figsize=(6, 5))
colors = ["#16a34a", "#dc2626", "#f59e0b"]
wedges, texts, autotexts = ax.pie(
    status_counts.values, labels=status_counts.index, autopct="%1.1f%%",
    colors=colors[:len(status_counts)], startangle=90,
    wedgeprops={"edgecolor": "white", "linewidth": 1.5},
)
ax.set_title("Order Status Breakdown")
fig.tight_layout()
fig.savefig(f"{VIS_DIR}/05_order_status_breakdown.png", dpi=150)
plt.close(fig)

# --------------------------------------------------------------------------
# 6. Data quality: before vs after missing-value counts (the "sales pitch" chart)
# --------------------------------------------------------------------------
raw = pd.read_csv("/home/claude/retail-data-cleaning-pipeline/data/raw/raw_sales_export.csv", dtype=str)
before_missing = {
    "OrderDate": (raw["OrderDate"].isna() | (raw["OrderDate"].str.strip() == "")).sum(),
    "UnitPrice": (raw["UnitPrice"].isna() | (raw["UnitPrice"].str.strip() == "")).sum(),
    "Quantity": raw["Quantity"].isna().sum(),
    "CustomerName": (raw["CustomerName"].isna() | (raw["CustomerName"].str.strip() == "")).sum(),
    "Duplicates": raw.duplicated().sum(),
}
after_missing = {
    "OrderDate": 0, "UnitPrice": 0, "Quantity": 0, "CustomerName": 0, "Duplicates": 0,
}

labels = list(before_missing.keys())
x = np.arange(len(labels))
width = 0.35

fig, ax = plt.subplots(figsize=(8.5, 4.5))
ax.bar(x - width/2, [before_missing[l] for l in labels], width, label="Before Cleaning", color="#dc2626")
ax.bar(x + width/2, [after_missing[l] for l in labels], width, label="After Cleaning", color="#16a34a")
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=15)
ax.set_ylabel("Issue Count")
ax.set_title("Data Quality Issues: Before vs. After Cleaning")
ax.legend()
fig.tight_layout()
fig.savefig(f"{VIS_DIR}/06_before_after_cleaning.png", dpi=150)
plt.close(fig)

print("All 6 charts saved to /visuals")
print("\nQuick business summary:")
print(f"  Total completed revenue: PKR {completed['Revenue'].sum():,.0f}")
print(f"  Best month: {monthly.idxmax()} (PKR {monthly.max():,.0f})")
print(f"  Top category: {by_cat.idxmax()} (PKR {by_cat.max():,.0f})")
print(f"  Return rate: {(df['Status'] == 'Returned').mean()*100:.1f}%")
