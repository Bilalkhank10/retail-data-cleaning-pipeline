# Data Quality Report

**Source file:** `raw_sales_export.csv`
**Rows in raw file:** 2,537
**Rows in cleaned file:** 2,452

## Issues found and fixed

| # | Issue | Count |
|---|-------|-------|
| 1 | Exact duplicate rows removed | 37 |
| 2 | Category spelling/casing variants collapsed to canonical values | 7 |
| 3 | Region spelling/casing variants collapsed to canonical values | 5 |
| 4 | Order dates missing in raw file | 48 |
| 5 | Order dates unparseable and dropped | 48 |
| 6 | Unit price missing/blank in raw file | 74 |
| 7 | Unit price still missing after currency-symbol cleanup (filled with category median) | 74 |
| 8 | Quantity missing (filled with median) | 40 |
| 9 | Quantity outliers flagged (data-entry errors, capped at 10.0) | 12 |
| 10 | Customer name missing (labeled "Guest / Unrecorded") | 32 |

**Net rows removed end-to-end:** 85 (duplicates + unparseable dates only — every other issue was fixed, not deleted)
